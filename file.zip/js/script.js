gsap.registerPlugin(ScrollTrigger);

function tagClassFor(status){
    if(status==='OUTDATED') return 'outdated';
    if(status==='UPDATED') return 'updated';
    return 'unknown';
}

function selectTab(name,updateUrl=true){
    const tabs=document.querySelectorAll('.tab-content');
    const btns=document.querySelectorAll('.tab-btn');
    tabs.forEach(t=>t.classList.remove('active'));
    btns.forEach(b=>b.classList.remove('active'));
    
    const target=document.getElementById('tab-'+name);
    if(!target) return;
    
    const tl=gsap.timeline();
    tl.to(btns,{scale:0.96,duration:0.12,ease:'power2.out'})
      .add(()=>{target.classList.add('active');})
      .to(btns,{scale:1,duration:0.18,ease:'power2.out'});

    const activeBtn=Array.from(btns).find(b=>b.dataset.tab===name);
    if(activeBtn) activeBtn.classList.add('active');

    if(updateUrl){
        const params=new URLSearchParams(window.location.search);
        params.set('tab',name);
        params.delete('script');
        const u=window.location.protocol+'//'+window.location.host+window.location.pathname+'?'+params.toString();
        window.history.pushState({},'',u);
    }
    ScrollTrigger.refresh();
}

function renderScripts(filter=''){
    const grid=document.getElementById('script-grid');
    grid.innerHTML='';
    const filtered = scriptsData
        .sort((a, b) => b.id - a.id) 
        .filter(s => s.title.toLowerCase().includes(filter.toLowerCase()));
    
    filtered.forEach(item=>{
        const thumb=item.youtube?`https://img.youtube.com/vi/${item.youtube}/mqdefault.jpg`:`https://images.unsplash.com/photo-1550751827-4bd374c3f58b?auto=format&fit=crop&q=80`;
        const tagCls=tagClassFor(item.status);
        const card=document.createElement('div');
        card.className='glass rounded-2xl overflow-hidden hover:bg-white/5 transition-all cursor-pointer group border border-white/5';
        card.setAttribute('data-id',item.id);
        card.addEventListener('click',()=>openModal(item));
        card.innerHTML=`
            <div class="h-44 overflow-hidden relative">
                <img src="${thumb}" class="w-full h-full object-cover opacity-60 group-hover:opacity-100 group-hover:scale-110 transition-all duration-700">
                <div class="absolute inset-0 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity">
                    <div class="w-12 h-12 bg-white text-black rounded-full flex items-center justify-center font-bold">VIEW</div>
                </div>
            </div>
            <div class="p-4 flex items-start justify-between gap-3">
                <div class="flex-1">
                    <h3 class="text-lg font-bold mb-1">${item.title}</h3>
                    <p class="text-gray-500 text-xs line-clamp-2">${item.desc}</p>
                </div>
                <div class="flex items-start">
                    <span class="tag ${tagCls}">${item.status}</span>
                </div>
            </div>
        `;
        grid.appendChild(card);
    })
}

function openModal(item, updateUrl = true) {
    document.getElementById('modal-title').innerText = item.title;
    const modalTag = document.getElementById('modal-tag');
    modalTag.innerText = item.status;
    modalTag.className = 'tag ' + tagClassFor(item.status);
    document.getElementById('modal-desc').innerText = item.desc;
    
    const modalBtn = document.getElementById('modal-btn');
    modalBtn.classList.remove('disabled', 'shake-error');
    
    if (item.link === "#" || !item.link) {
        modalBtn.href = "javascript:void(0)";
        modalBtn.innerText = "NOT AVAILABLE";
        modalBtn.classList.add('disabled');
        
        modalBtn.onclick = (e) => {
            e.preventDefault();
            modalBtn.classList.remove('shake-error');
            void modalBtn.offsetWidth; 
            modalBtn.classList.add('shake-error');
            setTimeout(() => modalBtn.classList.remove('shake-error'), 500);
        };
    } else {
        modalBtn.href = item.link;
        modalBtn.innerText = "GET SCRIPT";
        modalBtn.onclick = null;
    }
    
    const vc = document.getElementById('modal-video-container');
    vc.innerHTML = item.youtube ? `<div class="video-container"><iframe src="https://www.youtube.com/embed/${item.youtube}?autoplay=1" frameborder="0" allowfullscreen></iframe></div>` : '';
    
    const modal = document.getElementById('script-modal');
    modal.classList.remove('hidden');
    modal.classList.add('flex');
    
    gsap.fromTo('#modal-content', { y: 40, opacity: 0 }, { y: 0, opacity: 1, duration: 0.45, ease: 'expo.out' });

    if (updateUrl) {
        const params = new URLSearchParams(window.location.search);
        params.set('tab', 'script');
        params.set('script', String(item.id));
        const u = window.location.protocol + '//' + window.location.host + window.location.pathname + '?' + params.toString();
        window.history.pushState({}, '', u);
    }
}



function closeModal(){
    const modal=document.getElementById('script-modal');
    gsap.to('#modal-content',{
        y:30,
        opacity:0,
        duration:0.25,
        onComplete:()=>{
            modal.classList.add('hidden');
            document.getElementById('modal-video-container').innerHTML='';
            const params=new URLSearchParams(window.location.search);
            params.delete('script');
            const u=window.location.protocol+'//'+window.location.host+window.location.pathname+(params.toString()?('?'+params.toString()):'');
            window.history.pushState({},'',u);
        }
    });
}

function copyCurrentLink(){
    navigator.clipboard.writeText(window.location.href).then(()=>{
        const btn=document.getElementById('modal-share');
        gsap.to(btn,{scale:0.96,duration:0.08,clearProps:'scale'});
    });
}

window.addEventListener('popstate',()=>{
    const params=new URLSearchParams(window.location.search);
    const tab=params.get('tab')||'profile';
    selectTab(tab,false);
    const sid=params.get('script');
    if(sid){
        const itm=scriptsData.find(s=>String(s.id)===sid);
        if(itm) openModal(itm,false);
    } else {
        const modal=document.getElementById('script-modal');
        if(!modal.classList.contains('hidden')) closeModal();
    }
});

window.onload=()=>{
    renderScripts();
    const params=new URLSearchParams(window.location.search);
    const tab=params.get('tab')||'profile';
    selectTab(tab,false);
    
    const sid=params.get('script');
    if(sid){
        const itm=scriptsData.find(s=>String(s.id)===sid);
        if(itm) openModal(itm,false);
    }

    const tl=gsap.timeline();
    tl.to('#loader-text span',{y:0,stagger:0.08,duration:0.7,ease:'power4.out'})
      .to('#loader-bar',{width:'100%',duration:0.7})
      .to('#loader',{yPercent:-100,duration:0.9,ease:'expo.inOut'})
      .from('#hero-title',{y:80,opacity:0,duration:1.05},'-=0.5')
      .to('#hero-sub',{opacity:1,y:0},'-=0.7')
      .to('#main-nav',{opacity:1,y:0},'-=0.7');

    document.querySelectorAll('.reveal').forEach(el=>{
        gsap.to(el,{scrollTrigger:el,opacity:1,y:0,duration:0.9,ease:'power3.out'});
    });

    const cursor=document.getElementById('cursor');
    window.addEventListener('mousemove',e=>{
        gsap.to(cursor,{x:e.clientX,y:e.clientY,duration:0.08});
    });

    document.querySelectorAll('.tab-btn').forEach(b=>{
        b.addEventListener('click',()=>selectTab(b.dataset.tab));
    });

    document.getElementById('script-search').addEventListener('input',e=>renderScripts(e.target.value));
    document.getElementById('modal-share').addEventListener('click',copyCurrentLink);
}
